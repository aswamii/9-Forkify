export const proxy = 'https://cors-anywhere.herokuapp.com/';
export const key = '5f0494b44e27bdfc4dac54f02f5a469b';